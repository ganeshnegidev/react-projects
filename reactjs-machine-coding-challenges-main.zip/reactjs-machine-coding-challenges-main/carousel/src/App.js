import logo from './logo.svg';
import './App.css';
import Carousel from './Components/Carousel/Carousel';

function App() {
  return (
    <div className="App">
      <Carousel />
    </div>
  );
}

export default App;
