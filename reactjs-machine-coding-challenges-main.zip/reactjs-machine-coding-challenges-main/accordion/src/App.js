import Accordion from './Component/Accordion/Accordion';
import './App.css';

function App() {
  return (
    <div className="App">
      <Accordion />
    </div>
  );
}

export default App;
