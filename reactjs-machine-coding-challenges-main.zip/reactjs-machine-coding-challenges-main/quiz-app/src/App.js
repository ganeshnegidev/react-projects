import logo from './logo.svg';
import './App.css';
import Question from './Components/Question/Question';

function App() {
  return (
    <div className="App">
      <Question />
    </div>
  );
}

export default App;
